GRANT ALL PRIVILEGES ON MES4_Analysis.* TO 'example_user'@'%';
GRANT ALL PRIVILEGES ON mes4.* TO 'example_user'@'%';
FLUSH PRIVILEGES;